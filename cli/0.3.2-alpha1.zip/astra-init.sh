#!/bin/bash

export PATH=$PATH:"$HOME/.astra/cli"
#echo "$(tput setaf 2)[OK]$(tput setaf 7) - Astra added to the path"

containsElement () {
  # This function from http://stackoverflow.com/a/8574392/107591
  local e
  for e in "${@:2}"; do [[ "$e" == "$1" ]] && return 0; done
  return 1
}

function _complete_astra_group_db() {
  # Get completion data
  COMPREPLY=()
  CURR_WORD=${COMP_WORDS[COMP_CWORD]}
  PREV_WORD=${COMP_WORDS[COMP_CWORD-1]}
  CURR_CMD=
  if [[ ${COMP_CWORD} -ge 2 ]]; then
    CURR_CMD=${COMP_WORDS[2]}
  fi

  COMMANDS="create list delete"
  if [[ ${COMP_CWORD} -eq 2 ]]; then
    COMPREPLY=( $(compgen -W "${COMMANDS} ${DEFAULT_GROUP_COMMAND_COMPLETIONS}" -- ${CURR_WORD}) )
    echo ${COMPREPLY[@]}
    return 0
  fi

  case ${CURR_CMD} in
    create)
      COMPREPLY=( $(_complete_astra_group_db_command_create "${COMMANDS}" ) )
      echo ${COMPREPLY[@]}
      return $?
      ;;
    delete)
      COMPREPLY=( $(_complete_astra_group_db_command_delete "${COMMANDS}" ) )
      echo ${COMPREPLY[@]}
      return $?
      ;;
    list)
      COMPREPLY=( $(_complete_astra_group_db_command_list "${COMMANDS}" ) )
      echo ${COMPREPLY[@]}
      return $?
      ;;
  esac
}

function _complete_astra_group_db_command_create() {
  # Get completion data
  COMPREPLY=()
  CURR_WORD=${COMP_WORDS[COMP_CWORD]}
  PREV_WORD=${COMP_WORDS[COMP_CWORD-1]}
  COMMANDS=$1

  FLAG_OPTS="--debug"
  ARG_OPTS="--token --config-file --keyspace --region --log -ks -r -t -conf -f --format --config"

  $( containsElement ${PREV_WORD} ${ARG_OPTS[@]} )
  SAW_ARG=$?
  if [[ ${SAW_ARG} -eq 0 ]]; then
    ARG_VALUES=
    ARG_GENERATED_VALUES=
    case ${PREV_WORD} in
      --config-file)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      --log)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -conf|--config)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -t|--token)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -ks|--keyspace)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -r|--region)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -f|--format)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
    esac
  fi

  ARGUMENTS=
  COMPREPLY=( $(compgen -W "${FLAG_OPTS} ${ARG_OPTS} ${ARGUMENTS}" -- ${CURR_WORD}) )
  echo ${COMPREPLY[@]}
  return 0
}

function _complete_astra_group_db_command_delete() {
  # Get completion data
  COMPREPLY=()
  CURR_WORD=${COMP_WORDS[COMP_CWORD]}
  PREV_WORD=${COMP_WORDS[COMP_CWORD-1]}
  COMMANDS=$1

  FLAG_OPTS="--debug"
  ARG_OPTS="--token --config-file --log -t -conf -f --format --config"

  $( containsElement ${PREV_WORD} ${ARG_OPTS[@]} )
  SAW_ARG=$?
  if [[ ${SAW_ARG} -eq 0 ]]; then
    ARG_VALUES=
    ARG_GENERATED_VALUES=
    case ${PREV_WORD} in
      --config-file)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      --log)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -conf|--config)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -t|--token)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -f|--format)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
    esac
  fi

  ARGUMENTS=
  COMPREPLY=( $(compgen -W "${FLAG_OPTS} ${ARG_OPTS} ${ARGUMENTS}" -- ${CURR_WORD}) )
  echo ${COMPREPLY[@]}
  return 0
}

function _complete_astra_group_db_command_list() {
  # Get completion data
  COMPREPLY=()
  CURR_WORD=${COMP_WORDS[COMP_CWORD]}
  PREV_WORD=${COMP_WORDS[COMP_CWORD-1]}
  COMMANDS=$1

  FLAG_OPTS="--debug"
  ARG_OPTS="--token --config-file --log -t -conf -f --format --config"

  $( containsElement ${PREV_WORD} ${ARG_OPTS[@]} )
  SAW_ARG=$?
  if [[ ${SAW_ARG} -eq 0 ]]; then
    ARG_VALUES=
    ARG_GENERATED_VALUES=
    case ${PREV_WORD} in
      --config-file)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      --log)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -conf|--config)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -t|--token)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -f|--format)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
    esac
  fi

  ARGUMENTS=
  COMPREPLY=( $(compgen -W "${FLAG_OPTS} ${ARG_OPTS} ${ARGUMENTS}" -- ${CURR_WORD}) )
  echo ${COMPREPLY[@]}
  return 0
}

function _complete_astra_group_config() {
  # Get completion data
  COMPREPLY=()
  CURR_WORD=${COMP_WORDS[COMP_CWORD]}
  PREV_WORD=${COMP_WORDS[COMP_CWORD-1]}
  CURR_CMD=
  if [[ ${COMP_CWORD} -ge 2 ]]; then
    CURR_CMD=${COMP_WORDS[2]}
  fi

  COMMANDS="default show create list delete"
  if [[ ${COMP_CWORD} -eq 2 ]]; then
    COMPREPLY=( $(compgen -W "${COMMANDS} ${DEFAULT_GROUP_COMMAND_COMPLETIONS}" -- ${CURR_WORD}) )
    echo ${COMPREPLY[@]}
    return 0
  fi

  case ${CURR_CMD} in
    create)
      COMPREPLY=( $(_complete_astra_group_config_command_create "${COMMANDS}" ) )
      echo ${COMPREPLY[@]}
      return $?
      ;;
    default)
      COMPREPLY=( $(_complete_astra_group_config_command_default "${COMMANDS}" ) )
      echo ${COMPREPLY[@]}
      return $?
      ;;
    delete)
      COMPREPLY=( $(_complete_astra_group_config_command_delete "${COMMANDS}" ) )
      echo ${COMPREPLY[@]}
      return $?
      ;;
    show)
      COMPREPLY=( $(_complete_astra_group_config_command_show "${COMMANDS}" ) )
      echo ${COMPREPLY[@]}
      return $?
      ;;
    list)
      COMPREPLY=( $(_complete_astra_group_config_command_list "${COMMANDS}" ) )
      echo ${COMPREPLY[@]}
      return $?
      ;;
  esac
}

function _complete_astra_group_config_command_create() {
  # Get completion data
  COMPREPLY=()
  CURR_WORD=${COMP_WORDS[COMP_CWORD]}
  PREV_WORD=${COMP_WORDS[COMP_CWORD-1]}
  COMMANDS=$1

  FLAG_OPTS="--debug"
  ARG_OPTS="--token --config-file -t -f --format"

  $( containsElement ${PREV_WORD} ${ARG_OPTS[@]} )
  SAW_ARG=$?
  if [[ ${SAW_ARG} -eq 0 ]]; then
    ARG_VALUES=
    ARG_GENERATED_VALUES=
    case ${PREV_WORD} in
      --config-file)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -t|--token)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -f|--format)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
    esac
  fi

  ARGUMENTS=
  COMPREPLY=( $(compgen -W "${FLAG_OPTS} ${ARG_OPTS} ${ARGUMENTS}" -- ${CURR_WORD}) )
  echo ${COMPREPLY[@]}
  return 0
}

function _complete_astra_group_config_command_default() {
  # Get completion data
  COMPREPLY=()
  CURR_WORD=${COMP_WORDS[COMP_CWORD]}
  PREV_WORD=${COMP_WORDS[COMP_CWORD-1]}
  COMMANDS=$1

  FLAG_OPTS="--debug"
  ARG_OPTS="--config-file -f --format"

  $( containsElement ${PREV_WORD} ${ARG_OPTS[@]} )
  SAW_ARG=$?
  if [[ ${SAW_ARG} -eq 0 ]]; then
    ARG_VALUES=
    ARG_GENERATED_VALUES=
    case ${PREV_WORD} in
      --config-file)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -f|--format)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
    esac
  fi

  ARGUMENTS=
  COMPREPLY=( $(compgen -W "${FLAG_OPTS} ${ARG_OPTS} ${ARGUMENTS}" -- ${CURR_WORD}) )
  echo ${COMPREPLY[@]}
  return 0
}

function _complete_astra_group_config_command_delete() {
  # Get completion data
  COMPREPLY=()
  CURR_WORD=${COMP_WORDS[COMP_CWORD]}
  PREV_WORD=${COMP_WORDS[COMP_CWORD-1]}
  COMMANDS=$1

  FLAG_OPTS="--debug"
  ARG_OPTS="--config-file -f --format"

  $( containsElement ${PREV_WORD} ${ARG_OPTS[@]} )
  SAW_ARG=$?
  if [[ ${SAW_ARG} -eq 0 ]]; then
    ARG_VALUES=
    ARG_GENERATED_VALUES=
    case ${PREV_WORD} in
      --config-file)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -f|--format)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
    esac
  fi

  ARGUMENTS=
  COMPREPLY=( $(compgen -W "${FLAG_OPTS} ${ARG_OPTS} ${ARGUMENTS}" -- ${CURR_WORD}) )
  echo ${COMPREPLY[@]}
  return 0
}

function _complete_astra_group_config_command_show() {
  # Get completion data
  COMPREPLY=()
  CURR_WORD=${COMP_WORDS[COMP_CWORD]}
  PREV_WORD=${COMP_WORDS[COMP_CWORD-1]}
  COMMANDS=$1

  FLAG_OPTS="--debug"
  ARG_OPTS="--config-file -f --format"

  $( containsElement ${PREV_WORD} ${ARG_OPTS[@]} )
  SAW_ARG=$?
  if [[ ${SAW_ARG} -eq 0 ]]; then
    ARG_VALUES=
    ARG_GENERATED_VALUES=
    case ${PREV_WORD} in
      --config-file)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -f|--format)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
    esac
  fi

  ARGUMENTS=
  COMPREPLY=( $(compgen -W "${FLAG_OPTS} ${ARG_OPTS} ${ARGUMENTS}" -- ${CURR_WORD}) )
  echo ${COMPREPLY[@]}
  return 0
}

function _complete_astra_group_config_command_list() {
  # Get completion data
  COMPREPLY=()
  CURR_WORD=${COMP_WORDS[COMP_CWORD]}
  PREV_WORD=${COMP_WORDS[COMP_CWORD-1]}
  COMMANDS=$1

  FLAG_OPTS="--debug"
  ARG_OPTS="--config-file -f --format"

  $( containsElement ${PREV_WORD} ${ARG_OPTS[@]} )
  SAW_ARG=$?
  if [[ ${SAW_ARG} -eq 0 ]]; then
    ARG_VALUES=
    ARG_GENERATED_VALUES=
    case ${PREV_WORD} in
      --config-file)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -f|--format)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
    esac
  fi

  ARGUMENTS=
  COMPREPLY=( $(compgen -W "${FLAG_OPTS} ${ARG_OPTS} ${ARGUMENTS}" -- ${CURR_WORD}) )
  echo ${COMPREPLY[@]}
  return 0
}

function _complete_astra_command_setup() {
  # Get completion data
  COMPREPLY=()
  CURR_WORD=${COMP_WORDS[COMP_CWORD]}
  PREV_WORD=${COMP_WORDS[COMP_CWORD-1]}
  COMMANDS=$1

  FLAG_OPTS="--debug"
  ARG_OPTS="--config-file -f --format"

  $( containsElement ${PREV_WORD} ${ARG_OPTS[@]} )
  SAW_ARG=$?
  if [[ ${SAW_ARG} -eq 0 ]]; then
    ARG_VALUES=
    ARG_GENERATED_VALUES=
    case ${PREV_WORD} in
      --config-file)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -f|--format)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
    esac
  fi

  ARGUMENTS=
  COMPREPLY=( $(compgen -W "${FLAG_OPTS} ${ARG_OPTS} ${ARGUMENTS}" -- ${CURR_WORD}) )
  echo ${COMPREPLY[@]}
  return 0
}

function _complete_astra_command_help() {
  # Get completion data
  COMPREPLY=()
  CURR_WORD=${COMP_WORDS[COMP_CWORD]}
  PREV_WORD=${COMP_WORDS[COMP_CWORD-1]}
  COMMANDS=$1

  FLAG_OPTS=""
  ARG_OPTS=""

  ARGUMENTS=
  COMPREPLY=( $(compgen -W "${FLAG_OPTS} ${ARG_OPTS} ${ARGUMENTS}" -- ${CURR_WORD}) )
  echo ${COMPREPLY[@]}
  return 0
}

function _complete_astra_command_shell() {
  # Get completion data
  COMPREPLY=()
  CURR_WORD=${COMP_WORDS[COMP_CWORD]}
  PREV_WORD=${COMP_WORDS[COMP_CWORD-1]}
  COMMANDS=$1

  FLAG_OPTS="--debug -v --version"
  ARG_OPTS="--token --config-file --log -t -conf -f --format --config"

  $( containsElement ${PREV_WORD} ${ARG_OPTS[@]} )
  SAW_ARG=$?
  if [[ ${SAW_ARG} -eq 0 ]]; then
    ARG_VALUES=
    ARG_GENERATED_VALUES=
    case ${PREV_WORD} in
      --config-file)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      --log)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -conf|--config)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -t|--token)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
      -f|--format)
        COMPREPLY=( $(compgen -W "${ARG_VALUES} ${ARG_GENERATED_VALUES}" -- ${CURR_WORD}) )
        echo ${COMPREPLY[@]}
        return 0
        ;;
    esac
  fi

  ARGUMENTS=
  COMPREPLY=( $(compgen -W "${FLAG_OPTS} ${ARG_OPTS} ${ARGUMENTS}" -- ${CURR_WORD}) )
  echo ${COMPREPLY[@]}
  return 0
}

function _complete_astra() {
  # Get completion data
  CURR_WORD=${COMP_WORDS[COMP_CWORD]}
  PREV_WORD=${COMP_WORDS[COMP_CWORD-1]}
  CURR_CMD=
  if [[ ${COMP_CWORD} -ge 1 ]]; then
    CURR_CMD=${COMP_WORDS[1]}
  fi

  COMMANDS="help shell setup config db"
  if [[ ${COMP_CWORD} -eq 1 ]]; then
    COMPREPLY=( $(_complete_astra_command_shell "${COMMANDS}" ) )
    DEFAULT_COMMAND_COMPLETIONS=(${COMPREPLY[@]})
    COMPREPLY=()
    COMPREPLY=( $(compgen -W "${COMMANDS} ${DEFAULT_COMMAND_COMPLETIONS}" -- ${CURR_WORD}) )
    return 0
  fi

  case ${CURR_CMD} in 
    db)
      COMPREPLY=( $( _complete_astra_group_db ) )
      return $?
      ;;
    config)
      COMPREPLY=( $( _complete_astra_group_config ) )
      return $?
      ;;
    setup)
      COMPREPLY=( $(_complete_astra_command_setup "${COMMANDS}" ) )
      return $?
      ;;
    help)
      COMPREPLY=( $(_complete_astra_command_help "${COMMANDS}" ) )
      return $?
      ;;
    shell)
      COMPREPLY=( $(_complete_astra_command_shell "${COMMANDS}" ) )
      return $?
      ;;
  esac

}

complete -F _complete_astra astra

#echo "$(tput setaf 2)[OK]$(tput setaf 7) - Astra autocompletion ready"
